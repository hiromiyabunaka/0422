import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Zap, Clock, TrendingUp, CheckCircle2, Mail, Send, Mic, MessageSquare, Radio, Video, Tv, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './components/ui/accordion';

function App() {
  const [email, setEmail] = useState('');
  const [showNewsletter, setShowNewsletter] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg"
            alt="未来のテクノロジー"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-navy-900/40"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6 text-white">
              テクノロジーで描く
              <br />
              人とビジネスの新しい未来
            </h1>
            <p className="text-xl md:text-2xl text-gray-100 mb-8 leading-relaxed">
              7chAI× for Bizが実現する、より創造的で
              <br />
              豊かな社会へのイノベーション
            </p>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center px-8 py-4 text-lg font-semibold text-navy-900 bg-white rounded-full shadow-lg hover:bg-navy-50 hover:shadow-xl transition-all duration-200"
            >
              導入前ミーティング（無料）
              <ArrowRight className="ml-2 h-5 w-5" />
            </motion.button>
          </motion.div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-24 bg-gradient-to-b from-white to-slate-50">
        <div className="container mx-auto px-4">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-bold text-center mb-16 relative"
          >
            <span className="relative">
              放送×AIの革新的な実績
              <div className="absolute bottom-0 left-0 w-full h-1 bg-navy-600/20"></div>
            </span>
          </motion.h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Mic className="w-12 h-12 text-navy-600" />,
                title: "AIアナウンサー",
                description: "自然な話し方で24時間ニュースを配信。感情表現や間の取り方まで人間らしい放送を実現",
                metric: "導入局数 25社",
                image: "https://images.pexels.com/photos/7605913/pexels-photo-7605913.jpeg"
              },
              {
                icon: <MessageSquare className="w-12 h-12 text-navy-600" />,
                title: "対話型AIコメンテーター",
                description: "スポーツ中継での臨場感あるリアルタイム解説。視聴者との対話でより深い番組体験を提供",
                metric: "月間対話数 100万件",
                image: "https://images.pexels.com/photos/8867482/pexels-photo-8867482.jpeg"
              },
              {
                icon: <Radio className="w-12 h-12 text-navy-600" />,
                title: "自動音声認識字幕",
                description: "99.9%の精度で生放送の音声を自動字幕化。あらゆる番組のアクセシビリティを向上",
                metric: "字幕精度 99.9%",
                image: "https://images.pexels.com/photos/8867184/pexels-photo-8867184.jpeg"
              },
              {
                icon: <Video className="w-12 h-12 text-navy-600" />,
                title: "映像自動要約",
                description: "長時間の番組を最適な長さにダイジェスト化。ハイライトシーンを自動で抽出",
                metric: "処理時間 1/10に短縮",
                image: "https://images.pexels.com/photos/8867265/pexels-photo-8867265.jpeg"
              },
              {
                icon: <Tv className="w-12 h-12 text-navy-600" />,
                title: "視聴者行動分析",
                description: "リアルタイムの視聴傾向を分析し、最適なコンテンツを提案。視聴率向上に貢献",
                metric: "視聴率 平均15%向上",
                image: "https://images.pexels.com/photos/8867434/pexels-photo-8867434.jpeg"
              }
            ].map((achievement, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 ${index > 2 ? 'lg:col-span-2 md:col-span-1' : ''}`}
              >
                <div className="mb-4">{achievement.icon}</div>
                <h3 className="text-xl font-bold mb-3">{achievement.title}</h3>
                <p className="text-gray-600 leading-relaxed mb-4">{achievement.description}</p>
                <div className="text-navy-600 font-semibold mb-4">{achievement.metric}</div>
                <div className="rounded-lg overflow-hidden">
                  <img
                    src={achievement.image}
                    alt={achievement.title}
                    className="w-full h-48 object-cover transform hover:scale-105 transition-transform duration-300"
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pain Points Section */}
      <section className="py-24 bg-gradient-to-b from-slate-50 to-white">
        <div className="container mx-auto px-4">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-bold text-center mb-16 relative"
          >
            <span className="relative">
              大手企業が抱える課題
              <div className="absolute bottom-0 left-0 w-full h-1 bg-navy-600/20"></div>
            </span>
          </motion.h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Clock className="w-8 h-8 text-navy-600" />,
                title: "時間のムダ",
                description: "ルーチンワークに時間を取られ、本来注力すべき業務に集中できない",
                image: "https://images.pexels.com/photos/3183153/pexels-photo-3183153.jpeg"
              },
              {
                icon: <Zap className="w-8 h-8 text-navy-600" />,
                title: "人材リソース",
                description: "人手不足による業務の停滞や、品質の低下が懸念される",
                image: "https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg"
              },
              {
                icon: <TrendingUp className="w-8 h-8 text-navy-600" />,
                title: "コスト増大",
                description: "人件費の上昇や、非効率な業務プロセスによるコストの増加",
                image: "https://images.pexels.com/photos/7567434/pexels-photo-7567434.jpeg"
              }
            ].map((item, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden"
              >
                <div className="mb-4">{item.icon}</div>
                <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed mb-4">{item.description}</p>
                <div className="rounded-lg overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-48 object-cover transform hover:scale-105 transition-transform duration-300"
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-24 bg-gradient-to-b from-white to-slate-50 relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-5xl mx-auto">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-4xl font-bold text-center mb-16"
            >
              <span className="relative inline-block">
                7chAI× for Bizが創る、幸せな未来
                <div className="absolute bottom-0 left-0 w-full h-1 bg-navy-600/20"></div>
              </span>
            </motion.h2>

            <div className="grid md:grid-cols-2 gap-8 mb-16">
              {[
                {
                  title: "業務効率の革新",
                  description: "AIによる24時間365日の安定した業務遂行で、効率性を最大化",
                  image: "https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg"
                },
                {
                  title: "クリエイティブな時間の創出",
                  description: "定型業務から解放され、より創造的な仕事に集中できる環境を実現",
                  image: "https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg"
                },
                {
                  title: "働く喜びの向上",
                  description: "従業員一人一人が、やりがいのある仕事に専念できる職場づくり",
                  image: "https://images.pexels.com/photos/3182746/pexels-photo-3182746.jpeg"
                },
                {
                  title: "持続可能な成長",
                  description: "コスト削減と品質向上の両立で、企業の持続的な発展を支援",
                  image: "https://images.pexels.com/photos/3182781/pexels-photo-3182781.jpeg"
                }
              ].map((solution, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300"
                >
                  <div className="h-48 overflow-hidden">
                    <img
                      src={solution.image}
                      alt={solution.title}
                      className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{solution.title}</h3>
                    <p className="text-gray-600">{solution.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Customer Reviews Section */}
      <section className="py-24 bg-gradient-to-b from-slate-50 to-white">
        <div className="container mx-auto px-4">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-bold text-center mb-16 relative"
          >
            <span className="relative">
              導入企業の声
              <div className="absolute bottom-0 left-0 w-full h-1 bg-navy-600/20"></div>
            </span>
          </motion.h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                company: "全国放送株式会社",
                role: "制作部長",
                comment: "AIアナウンサーの導入により、24時間ニュース配信が可能になりました。視聴者からの評判も上々です。",
                image: "https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg"
              },
              {
                company: "スポーツメディア株式会社",
                role: "技術統括部長",
                comment: "リアルタイムの試合解説がAIで可能になり、視聴者エンゲージメントが大幅に向上しました。",
                image: "https://images.pexels.com/photos/3182746/pexels-photo-3182746.jpeg"
              },
              {
                company: "地方テレビ放送",
                role: "編成部長",
                comment: "自動字幕生成により、すべての番組でバリアフリー対応が実現。視聴者層が大きく広がりました。",
                image: "https://images.pexels.com/photos/3182781/pexels-photo-3182781.jpeg"
              }
            ].map((review, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <div className="mb-6 h-48 rounded-lg overflow-hidden">
                  <img
                    src={review.image}
                    alt={review.company}
                    className="w-full h-full object-cover"
                  />
                </div>
                <p className="text-gray-600 italic mb-4">"{review.comment}"</p>
                <div className="text-navy-800 font-semibold">{review.company}</div>
                <div className="text-navy-600">{review.role}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-24 bg-gradient-to-b from-white to-slate-50">
        <div className="container mx-auto px-4">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-bold text-center mb-16 relative"
          >
            <span className="relative">
              料金プラン
              <div className="absolute bottom-0 left-0 w-full h-1 bg-navy-600/20"></div>
            </span>
          </motion.h2>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                name: "スタンダード",
                price: "50",
                features: [
                  "AIアナウンサー（1キャラクター）",
                  "自動字幕生成",
                  "基本的な分析レポート",
                  "平日サポート"
                ]
              },
              {
                name: "プロフェッショナル",
                price: "100",
                isPopular: true,
                features: [
                  "AIアナウンサー（3キャラクター）",
                  "自動字幕生成",
                  "リアルタイムAI解説",
                  "詳細な分析レポート",
                  "24時間365日サポート"
                ]
              },
              {
                name: "エンタープライズ",
                price: "200",
                features: [
                  "AIアナウンサー（無制限）",
                  "自動字幕生成",
                  "リアルタイムAI解説",
                  "カスタム分析レポート",
                  "専任サポート担当者",
                  "オンサイトトレーニング"
                ]
              }
            ].map((plan, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-2xl shadow-lg p-8 ${
                  plan.isPopular
                    ? 'ring-2 ring-navy-600 scale-105 z-10'
                    : 'hover:shadow-xl'
                } transition-all duration-300`}
              >
                {plan.isPopular && (
                  <div className="text-navy-600 font-semibold text-sm mb-4">
                    おすすめプラン
                  </div>
                )}
                <h3 className="text-2xl font-bold mb-4">{plan.name}</h3>
                <div className="text-4xl font-bold mb-6">
                  ¥{plan.price},000
                  <span className="text-base font-normal text-gray-600">/月～</span>
                </div>
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <CheckCircle2 className="h-5 w-5 text-navy-600 mr-2" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button className={`w-full py-3 rounded-lg font-semibold transition-colors duration-200 ${
                  plan.isPopular
                    ? 'bg-navy-600 text-white hover:bg-navy-700'
                    : 'bg-navy-100 text-navy-800 hover:bg-navy-200'
                }`}>
                  プランを選択
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-gradient-to-b from-slate-50 to-white">
        <div className="container mx-auto px-4">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-bold text-center mb-16 relative"
          >
            <span className="relative">
              よくある質問
              <div className="absolute bottom-0 left-0 w-full h-1 bg-navy-600/20"></div>
            </span>
          </motion.h2>

          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              {[
                {
                  question: "導入にはどのくらいの期間が必要ですか？",
                  answer: "基本的な導入は2週間程度で完了します。カスタマイズが必要な場合は、要件に応じて1〜2ヶ月程度かかることがあります。"
                },
                {
                  question: "既存のシステムとの連携は可能ですか？",
                  answer: "はい、可能です。標準的なAPIを提供しており、多くの放送システムとの連携実績があります。詳細は個別にご相談ください。"
                },
                {
                  question: "トレーニングやサポートは提供されますか？",
                  answer: "はい。導入時の基本トレーニングに加え、継続的なテクニカルサポートを提供しています。プランによってはオンサイトでのトレーニングも可能です。"
                },
                {
                  question: "カスタマイズは可能ですか？",
                  answer: "はい。AIアナウンサーの声質や話し方、字幕のスタイル、分析レポートの内容など、多くの要素をカスタマイズできます。"
                }
              ].map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <AccordionItem value={`item-${index}`} className="border rounded-lg p-4">
                    <AccordionTrigger className="text-left">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-24 bg-gradient-to-b from-white to-slate-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Contact Form */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="bg-white p-8 rounded-xl shadow-lg"
              >
                <h3 className="text-2xl font-bold mb-6">お問い合わせ</h3>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      お名前
                    </label>
                    <input
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      メールアドレス
                    </label>
                    <input
                      type="email"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      お問い合わせ内容
                    </label>
                    <textarea
                      rows={4}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-transparent"
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-navy-600 text-white py-3 rounded-lg hover:bg-navy-700 transition-colors duration-200 flex items-center justify-center"
                  >
                    <Send className="w-5 h-5 mr-2" />
                    送信する
                  </button>
                </form>
              </motion.div>

              {/* Newsletter Signup */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="bg-white p-8 rounded-xl shadow-lg"
              >
                <h3 className="text-2xl font-bold mb-6">メールマガジン登録</h3>
                <p className="text-gray-600 mb-6">
                  最新のAI技術動向や活用事例、業界ニュースをお届けします
                </p>
                <div className="space-y-4">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="メールアドレスを入力"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-transparent"
                  />
                  <button
                    onClick={() => setShowNewsletter(true)}
                    className="w-full bg-navy-600 text-white py-3 rounded-lg hover:bg-navy-700 transition-colors duration-200 flex items-center justify-center"
                  >
                    <Mail className="w-5 h-5 mr-2" />
                    登録する
                  </button>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-navy-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h4 className="text-xl font-bold mb-4">7chAI× for Biz</h4>
              <p className="text-gray-400">
                放送業界のデジタルトランスフォーメーションを支援する革新的なAIソリューション
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">サービス</h4>
              <ul className="space-y-2">
                <li>AIアナウンサー</li>
                <li>自動字幕生成</li>
                <li>コンテンツ分析</li>
                <li>視聴者分析</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">会社情報</h4>
              <ul className="space-y-2">
                <li>会社概要</li>
                <li>採用情報</li>
                <li>プライバシーポリシー</li>
                <li>利用規約</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">お問い合わせ</h4>
              <p className="text-gray-400 mb-4">
                〒100-0001<br />
                東京都千代田区千代田1-1-1
              </p>
              <div className="flex space-x-4">
                <Facebook className="w-6 h-6" />
                <Twitter className="w-6 h-6" />
                <Instagram className="w-6 h-6" />
                <Youtube className="w-6 h-6" />
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 7chAI× for Biz. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;